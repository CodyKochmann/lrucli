""" command line interface for lru_cache """

try:
	from .__main__ import main
except ImportError:
	pass
